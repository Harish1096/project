from django.contrib import admin
from django.urls import path, include  # 'include' is used to reference your app's URL configuration

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('rbac_app.urls')),  # Make sure you include your app's urls.py here
]
