from django.apps import AppConfig


class RbacAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rbac_app'
