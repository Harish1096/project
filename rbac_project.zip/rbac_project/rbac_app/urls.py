from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Default route for the base URL
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('moderator/dashboard/', views.moderator_dashboard, name='moderator_dashboard'),
    path('user/profile/', views.user_profile, name='user_profile'),
    path('register/', views.register, name='register'),  # URL for registration
    path('login/', views.user_login, name='login'),  # URL for login
    path('logout/', views.user_logout, name='logout'),  # URL for logout
]


