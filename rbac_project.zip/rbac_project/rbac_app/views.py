from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import UserProfile  # Assuming you have a custom user profile model
from .decorators import check_role  # Assuming you have a custom decorator for role checking

from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib import messages

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            # Save the user to the database
            user = form.save()
            # Automatically log the user in after successful registration
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('user_profile')  # Redirect to user profile after successful registration
        else:
            # If form is invalid, show error messages
            messages.error(request, 'Please correct the error below.')
    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})


# Login view
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.shortcuts import render, redirect

def user_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome, {user.username}!')
            return redirect('admin_dashboard')  # Redirect based on user role (admin, moderator, etc.)
        else:
            messages.error(request, "Invalid username or password")
    return render(request, 'login.html')


# Admin Dashboard view (protected with login and role check)
@login_required
@check_role('admin')  # Ensure user has 'admin' role
def admin_dashboard(request):
    # Example data to pass to the template
    context = {
        'total_users': 50,  # Example count of total users
        'recent_activity': 'John updated their profile',  # Example recent activity
    }
    return render(request, 'admin_dashboard.html', context)

# Moderator Dashboard view (protected with login and role check)
@login_required
@check_role('moderator')  # Ensure user has 'moderator' role
def moderator_dashboard(request):
    # Example data for moderators
    context = {
        'new_reports': 3,  # Example count of new reports
        'pending_approval': 5,  # Example count of pending content
    }
    return render(request, 'moderator_dashboard.html', context)

# User Profile view (protected with login and role check)
@login_required
@check_role('user')  # Ensure user has 'user' role
def user_profile(request):
    return render(request, 'user_profile.html')

# Home view (accessible without login)
def home(request):
    return render(request, 'home.html')

# Logout view
def user_logout(request):
    logout(request)
    return redirect('login')  # Redirect to login page after logout

