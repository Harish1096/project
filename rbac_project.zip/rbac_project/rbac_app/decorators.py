from django.http import JsonResponse
from .models import UserProfile

def check_role(required_role):
    """
    Decorator to check if the user has the required role.
    """
    def decorator(view_func):
        def _wrapped_view(request, *args, **kwargs):
            # Ensure the user is logged in
            if not request.user.is_authenticated:
                return JsonResponse({'message': 'User not authenticated'}, status=401)

            try:
                # Fetch the user's profile to get the roles
                user_profile = UserProfile.objects.get(user=request.user)
                user_roles = [role.name for role in user_profile.roles.all()]
            except UserProfile.DoesNotExist:
                return JsonResponse({'message': 'User profile not found'}, status=404)

            # Check if the user has the required role
            if required_role not in user_roles:
                return JsonResponse({'message': 'Access Denied: Insufficient Permissions'}, status=403)

            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator
